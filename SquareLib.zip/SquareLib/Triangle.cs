﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SquareLib
{
    public class Triangle : Figure
    {
        double b;
        double c;

        public Triangle(double _a, double _b, double _c)
            : base(_a)
        {
            this.b = _b;
            this.c = _c;
        }

        //. Площадь треугольника .
        public double GetSquare()
        {
            if (IsExists())
            {
                double p = (a + b + c) / 2;
                double S = Math.Sqrt(p * (p - a) * (p - b) * (p - c));
                //Площадь треугольника
                return S;
            }
            var ex = new Exception("Треугольник не существует");
            throw ex;
        }

        public bool IsRectangular()
        {
            if (((a * a == b * b + c * c)
                || (b * b == a * a + c * c)
                || (c * c == b * b + a * a))
                && IsExists())
            { return true; }
            else { return false; }
        }

        private bool IsExists() 
        {
            if ((a > 0 && b > 0 && c > 0) && (a + b <= c || a + c <= b || b + c <= a))
            {
                return false;
            }
            return true;
        }
    }
}
