﻿using System;

namespace SquareLib
{
    public class Figure
    {
        //. Установим число PI .
        public const double pi = 3.1415f;

        public double a;

        public Figure(double _a)
        {
            a = _a;
        }
    }
 }
