﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SquareLib
{
    public class Circle : Figure
    {
        public Circle(double _a)
            : base(_a)
        {
        }

        //. Площадь круга .
        public double GetSquare()
        {
            if (IsExists()) return pi * (a * a);
            var ex = new Exception("Круг не существует");
            throw ex;
        }

        private bool IsExists()
        {
            if (a < 0)
            {
                return false;
            }
            return true;
        }
    }
}
