﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SquareLib;
using System;

namespace SquareLibTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestGetSquare_Triangle()
        {
            //. Расчет ожидания .
            double expected = Math.Sqrt(1.5 * (0.5) * (0.5) * (0.5));
            //. Вызов метода .
            var triangle = new Triangle(1, 1, 1);
            double result = triangle.GetSquare();
            //. Проверка .
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void TestGetSquare_Circle()
        {
            //. Расчет ожидания .
            double expected = 3.1415f;
            //. Вызов метода .
            var circle = new Circle(1);
            double result = circle.GetSquare();
            //. Проверка .
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void IsRectangular_True()
        {
            //. Ожидание: True .
            //. Вызов метода .
            var trio = new Triangle(1, 0.6, 0.8);
            bool result = trio.IsRectangular();
            //. Проверка .
            Assert.IsFalse(!result);
        }

        [TestMethod]
        public void IsRectangular_False()
        {
            //. Ожидание: False .
            //. Вызов метода .
            var triangle = new Triangle(1, 1, 1);
            bool result = triangle.IsRectangular();
            //. Проверка .
            Assert.IsFalse(result);
        }
    }
}
